#include <stdio.h>
#include "list.h"

/* ================= Bloco 1 ================= */

void create(t_list *list) {
    // TODO: inicializar a lista (size = 0)
}

int is_empty(t_list *list) {
    // TODO: retornar 1 se vazia, 0 caso contrário
    return 0;
}

int is_full(t_list *list) {
    // TODO: retornar 1 se size == MAX
    return 0;
}

int append(t_list *list, int element) {
    // TODO: inserir no final. Retornar 1 se sucesso, 0 se cheia
    return 0;
}

void print_list(t_list *list) {
    // TODO: imprimir os elementos separados por espaço, com \n no final
}

/* ================= Bloco 2 ================= */

int insert(t_list *list, int element, int index) {
    // TODO: inserir em 'index', deslocando os seguintes para a direita
    return 0;
}

int get(t_list *list, int index, int *out) {
    // TODO: colocar em *out o elemento de 'index'. Retornar 0 se inválido
    return 0;
}

int update(t_list *list, int element, int index) {
    // TODO: substituir o elemento de 'index' por 'element'
    return 0;
}

/* ================= Bloco 3 ================= */

int remove_by_index(t_list *list, int index) {
    // TODO: remover o elemento de 'index', deslocando os seguintes para a esquerda
    return 0;
}

int index_of(t_list *list, int element) {
    // TODO: retornar o primeiro índice de 'element', ou -1
    return -1;
}

int remove_by_element(t_list *list, int element) {
    // TODO: remover a primeira ocorrência de 'element'
    // dica: reusar index_of + remove_by_index
    return 0;
}

int count(t_list *list, int element) {
    // TODO: contar quantas vezes 'element' aparece
    return 0;
}

/* ================= Bloco 4 ================= */

int is_sorted(t_list *list) {
    // TODO: verificar se a lista está em ordem crescente
    return 0;
}

void copy(t_list *src, t_list *dest) {
    // TODO: copiar todos os elementos de src para dest
}

void copy_no_duplicates(t_list *src, t_list *dest) {
    // TODO: copiar de src para dest sem repetir elementos
}

void reverse_to(t_list *src, t_list *dest) {
    // TODO: inverter src, colocando o resultado em dest (sem alterar src)
}

void reverse_in_place(t_list *list) {
    // TODO: inverter a própria lista sem usar lista auxiliar
    // dica: trocar items[i] com items[size-1-i]
}

void remove_all(t_list *list, int element) {
    // TODO: remover TODAS as ocorrências de 'element'
}

/* ================= Bloco 5 ================= */

void merge_sorted(t_list *l1, t_list *l2, t_list *l3) {
    // TODO: l1 e l2 já ordenadas -> gerar l3 ordenada (merge do merge sort, O(n+m))
}

/* ================= Bloco 6 — Lista Ordenada ================= */

int insert_ordered(t_list *list, int element) {
    // TODO: inserir 'element' na posição correta para manter a ordem crescente
    return 0;
}

int search_binary(t_list *list, int element) {
    // TODO: busca binária (lista precisa estar ordenada). Retornar índice ou -1
    return -1;
}

int equals(t_list *l1, t_list *l2) {
    // TODO: retornar 1 se l1 e l2 têm os mesmos elementos, na mesma ordem
    return 0;
}
